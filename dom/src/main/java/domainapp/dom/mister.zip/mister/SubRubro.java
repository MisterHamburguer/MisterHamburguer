package domainapp.dom.mister;

import javax.jdo.annotations.IdentityType;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.VersionStrategy;

import org.apache.isis.applib.annotation.DomainObject;
import org.apache.isis.applib.annotation.MemberOrder;
import org.apache.isis.applib.annotation.Property;
import org.apache.isis.applib.services.eventbus.PropertyDomainEvent;
import org.apache.isis.applib.services.repository.RepositoryService;
@javax.jdo.annotations.PersistenceCapable(
        identityType=IdentityType.DATASTORE,
       schema = "mister",
        table = "SubRubro"
)
@javax.jdo.annotations.DatastoreIdentity(
        strategy=javax.jdo.annotations.IdGeneratorStrategy.IDENTITY,
         column="id")
@javax.jdo.annotations.Version(
//        strategy=VersionStrategy.VERSION_NUMBER,
        strategy= VersionStrategy.DATE_TIME,
        column="version")
@javax.jdo.annotations.Queries({
        @javax.jdo.annotations.Query(
                name = "findSB", language = "JDOQL",
                value = "SELECT "
                        + "FROM domainapp.dom.mister.SubRubro "),
        @javax.jdo.annotations.Query(
                name = "busPorDesSb", language = "JDOQL",
                value = "SELECT "
                        + "FROM domainapp.dom.mister.SubRubro "
                        + "WHERE descripcion.indexOf(:descripcion) >= 0 ")
})
@javax.jdo.annotations.Unique(name="SubRubro_des_UNQ", members = {"descripcion"})
@DomainObject

public class SubRubro implements Comparable<SubRubro>{
	@Persistent
	@MemberOrder(sequence="1")
	@javax.jdo.annotations.Column(allowsNull="false")
    private int codigo;
    	

    public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
    
	public static class DescripcionDomainEvent extends PropertyDomainEvent<SubRubro,String> {}
    @javax.jdo.annotations.Column(
            allowsNull="false"            
    )
    @Property(
        domainEvent = DescripcionDomainEvent.class
    )
    @Persistent
	@MemberOrder(sequence="2")
    private String descripcion;
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(final String descripcion) {
        this.descripcion = descripcion;
    }


    @Override
    public int compareTo(final SubRubro other) {
    	int salida=this.descripcion.compareTo(other.getDescripcion());
        return salida;
    }
 

	@javax.inject.Inject
    RepositoryService repositoryService;

}
